<?php
require_once("class/user.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>My Social Network</title>
</head>
<body> 
    <?php include("header.php"); ?> 
    <!-- Cover Area  -->

    <div class="cover">
        <!-- Profile img -->
        <div style="background-color:white ; text-align: center ; color: #405d9b; margin-bottom: 20px;">
            <img src="./img/cover_image.jpg" alt="img"  style="width:100% ; height: 200px;">
            <img src="./img/user_female.jpg" alt="imgs" class="profile_img"> <br>
            <br> 
        
            <div style="font: size 20px; "> 
                    Sahar alsalmy
                    <?php
                        //echo $ROW_USER['first_name'] ." ".$ROW_USER['last_name'] ;
                     ?> </div>
            <br>
            <div id="menu_buttons">TimeLinne</div>
            <div id="menu_buttons">About</div>
            <div id="menu_buttons">Friends</div>
            <div id="menu_buttons">Photos</div>
            <div id="menu_buttons">Settings</div>
            <br><br>

        </div>
        <!-- ===================================================================================== -->


     
          <!-- posts  area-->
            <!-- <div style="  min-height: 400px; width: 800px; margin-top: 4px; ">
                <div style="border: solid 1px #aaa; padding: 10px ; background-color: white;">

                    <form action="" method="post">
                    <textarea name="post" id="textPost" placeholder="Whate is in your mind? "></textarea>
                    <input type="submit" value="Post" id="post_button">  
                    <br> 
                    </form>

                </div>
                 ===================================================================================== -->
                <!-- <div id="post_bar" >-->

                    <!-- Post here  -->
    
                      
                </div>
        
             </div>            


          </div> 
        </div>

   

 
    
</body>
</html>