<!-- Top Area  -->

<?php
                             
    // require_once('./class/user.php');                       
    // $user = new User();
    // $ROW_USER = $user->get_user($ROW['user_id']);
    //     //print_r($ROW);

    // if($ROW_USER['gender'] == "Female")
    // {
    //     $image = "img/woman.png";

    // }
    // elseif($ROW_USER['gender'] == "Male"){
    //     $image ="img/man.png";

    // }

?>

<div class="blue_bar" style="height: 80px;" >
        <div class="blue_bar_in"><a style=" color:white;  
         text-decoration: none;" href="index.php">My SocialMedia</a> &nbsp; &nbsp;
            <!-- <input type="search " class="search_box  " placeholder="Search for pepole "> -->
            <a href="logout.php">
				<span style="font-size:18px;float:right; 
                 background-color: #04e65b; padding: 4px; border-radius: 4px;
                 margin:10px;color:white; ">Logout</span>
			</a>
              
           <a href="profile.php"> 

               <img src="img/user_female.jpg" 
            style="width: 50px; float: right ; border-radius:20%;"></a>

        </div>
        
    </div>